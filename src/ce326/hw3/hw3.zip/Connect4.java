package ce326.hw3;

// main class that starts the game
public class Connect4 
{
	public static void main(String args[])
	{	
		GUI newTest = new GUI();	// just starts the game
		newTest.frame.setVisible(true);	
	}
}
