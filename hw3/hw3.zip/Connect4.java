package ce326.hw3;

public class Connect4 
{
	public static void main(String args[])
	{	
		GUI newTest = new GUI();
		newTest.frame.setVisible(true);	
	}
}
